ESX = nil
local SetupComplete = false
local PlayerLoaded = false
local trainsActive = false

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(100)
	end
	ESX.PlayerData = ESX.GetPlayerData()
	PlayerLoaded = true
end)

Citizen.CreateThread(function()
	while not SetupComplete do
		Citizen.Wait(1000)
		if PlayerLoaded then
			ESX.TriggerServerCallback('trains:CheckNewVersion', function(isNewestVersion)
				if isNewestVersion then
					SetupComplete = true
				else
					SetupComplete = false
					ESX.ShowNotification(_U('need_setup'))
				end
			end)
		end
	end
end)
RegisterNetEvent('trains:startTrain')
AddEventHandler('trains:startTrain', function()
	local ModelHash = 0x3D6AAA9B -- this is the model for train
	if not IsModelInCdimage(ModelHash) then return end
	RequestModel(ModelHash) -- Request the model
	while not HasModelLoaded(ModelHash) do -- Waits for the model to load with a check so it does not get stuck in an infinite loop
	  Citizen.Wait(10)
	end
	
		function LoadTrainModels() -- f*ck your rails, too!
		tempmodel = GetHashKey("freight")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		
		tempmodel = GetHashKey("freightcar")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		
		tempmodel = GetHashKey("freightgrain")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		
		tempmodel = GetHashKey("freightcont1")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		
		tempmodel = GetHashKey("freightcont2")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		
		tempmodel = GetHashKey("freighttrailer")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end

		tempmodel = GetHashKey("tankercar")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		
		tempmodel = GetHashKey("metrotrain")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		
		tempmodel = GetHashKey("s_m_m_lsmetro_01")
		RequestModel(tempmodel)
		while not HasModelLoaded(tempmodel) do
			RequestModel(tempmodel)
			Citizen.Wait(0)
		end
		if Debug then 
			if Debug then print("XNL Log: Train Models Loaded" ) end
		end
	end

	LoadTrainModels()
	
	x = 2831.257
	y = 3300.364
	z = 51.969
	h = 334.186
	dir = math.random(0,1)
	DeleteAllTrains()
	Wait(100)
	train = 2
	veh = CreateMissionTrain(train,x,y,z,dir)
	while not DoesEntityExist(veh) do
		Wait(800)
	end
	Wait(200)
	
	veh2 = CreateMissionTrain(24,-618.0,-1476.8,16.2,0)
	while not DoesEntityExist(veh2) do
		Wait(800)
	end
	Wait(200)
	
	veh3 = CreateMissionTrain(24,40.2,-1201.3,31.0,1)
	while not DoesEntityExist(veh3) do
		Wait(800)
	end
	Wait(200)
	
	trainDriver = GetHashKey("s_m_m_lsmetro_01")
	
	driverPed = CreatePedInsideVehicle(veh, 26, trainDriver, -1, 1, true)
	driverPed2 = CreatePedInsideVehicle(veh2, 26, trainDriver, -1, 1, true)
	driverPed3 = CreatePedInsideVehicle(veh3, 26, trainDriver, -1, 1, true)
	
	SetBlockingOfNonTemporaryEvents(driverPed, true)
	SetPedFleeAttributes(driverPed, 0, 0)
	SetEntityInvincible(driverPed, true)
	SetEntityAsMissionEntity(driverPed, true)
	Wait(1000)
	
	SetBlockingOfNonTemporaryEvents(driverPed2, true)
	SetPedFleeAttributes(driverPed2, 0, 0)
	SetEntityInvincible(driverPed2, true)
	SetEntityAsMissionEntity(driverPed2, true)
	Wait(1000)
	
	SetBlockingOfNonTemporaryEvents(driverPed3, true)
	SetPedFleeAttributes(driverPed3, 0, 0)
	SetEntityInvincible(driverPed3, true)
	SetEntityAsMissionEntity(driverPed3, true)
	Wait(1000)
	
	SetModelAsNoLongerNeeded(trainDriver)
	TriggerServerEvent('trains:TrainStarted', true)
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1000)
		if not trainsActive then
			ESX.TriggerServerCallback('trains:CheckTrainActive', function(trainsGetActive)
				if not trainsGetActive then
					trainsActive = true
					TriggerEvent('trains:startTrain')
				else
					trainsActive = false
				end
			end)
		end
	end
end)

function ShowHelpNotification(text)
    ClearAllHelpMessages();
    SetTextComponentFormat("STRING");
    AddTextComponentString(text);
    DisplayHelpTextFromStringLabel(0, false, true, 2000);
end
