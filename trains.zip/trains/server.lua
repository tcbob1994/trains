ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local CurrentVersion = '1.1'
local isUptoDate = false
local trainsActive = false

PerformHttpRequest("https://raw.githubusercontent.com/tcbob1994/trains/main/VERSION.md", function(Error, NewVersion, Header)
	if CurrentVersion ~= NewVersion and tonumber(CurrentVersion) < tonumber(NewVersion) then
		print("\n")
		print("####")
		print("#### Trains")
		print("####")
		print("#### ^4Current Version: " .. CurrentVersion .. "^4")
		print("#### ^5Newest Version: " .. NewVersion .. "^5")
		print("####")
		print("#### ^4Outdated^4, please download the newest Version!")
		print("####")
		print("\n")
		isUptoDate = false
	else
		print("\n")
		print("####")
		print("#### Trains")
		print("####")
		print("#### ^4Current Version: " .. CurrentVersion .. "^4")
		print("#### ^5Newest Version: " .. NewVersion .. "^5")
		print("####")
		print("#### ^4Everything is Up to date! ^4")
		print("####")
		print("\n")
		isUptoDate = true
	end
end)

Citizen.CreateThread( function ()
    Wait(200)
    while true do 
        local players = GetPlayers()
		if #players == 0 then
			trainsActive = false
		end
        Wait (1000)
    end
end)

ESX.RegisterServerCallback('trains:CheckNewVersion', function(source, cb)
	cb(isUptoDate)
end)

ESX.RegisterServerCallback('trains:CheckTrainActive', function(source, cb)
	cb(trainsActive)
end)

RegisterNetEvent('trains:TrainStarted')
AddEventHandler('trains:TrainStarted', function (data)
	if data then
		trainsActive = true
	end
end)