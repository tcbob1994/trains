resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'made by bob#9423'

server_scripts {
    '@mysql-async/lib/MySQL.lua',
	'server.lua',
	'config.lua'
}

client_script{
	'client.lua',
	'config.lua'
}